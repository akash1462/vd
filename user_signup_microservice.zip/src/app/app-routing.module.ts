import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegisterComponent } from './USER/register/register.component';
import { LoginComponent } from './USER/login/login.component';
import { MentorDetailsComponent } from './USER/mentor-details/mentor-details.component';
import { SkillGuardService } from './USER/skill-guard.service';


const routes: Routes = [
  { path:'login', component:LoginComponent},
  { path:'register', component:RegisterComponent},
  { path:'mentorDetails', component:MentorDetailsComponent, canActivate:[SkillGuardService]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
