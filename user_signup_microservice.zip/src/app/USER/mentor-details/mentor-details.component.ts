import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SkillService } from '../skill.service';
import { Skill } from '../Skill';
import { Mentor } from '../Mentor';
import { Mentor_Skill } from '../Mentor_Skill';

@Component({
  selector: 'app-mentor-details',
  templateUrl: './mentor-details.component.html',
  styleUrls: ['./mentor-details.component.css']
})
export class MentorDetailsComponent implements OnInit {

  registrationForm: FormGroup;
  skillForm: FormGroup;
  userExists: boolean = false;
  skillList:Skill[] = [];
  mentorAdded:boolean = false;
  submittedSkill:boolean = false;
  errorMessage:string=null;

  constructor(private formBuild: FormBuilder, private router: Router, private skillService:SkillService) { }

  ngOnInit() {
    this.errorMessage = null;
    this.buildSkillForm()
    this.userExists = false;
    this.skillList = [];
    this.skillService.getAllSkillsObservable().subscribe(
      (data)=>{
        this.skillList = data;
      },
      (error)=>{
        console.log(error);
      }
    )
    this.registrationForm = this.formBuild.group({
      linkedInURL: ['', [
        Validators.required,
        Validators.maxLength(100),
      ]],
      yearsOfExperience: ['', [
        Validators.required,
        Validators.min(0),
        // Validators.
      ]],
      timeslot: ['', [
        Validators.required
      ]],
    })
  }
  get linkedInURL() {
    return this.registrationForm.get('linkedInURL');
  }
  get yearsOfExperience() {
    return this.registrationForm.get('yearsOfExperience');
  }
  get timeslot() {
    return this.registrationForm.get('timeslot');
  }

  buildSkillForm() {
    this.skillForm = this.formBuild.group({
      skill:['',[
        Validators.required
      ]],
      selfRating:['',[
        Validators.required,
        Validators.max(10),
        Validators.min(0)
      ]],
      yearsExperience: ['', [
        Validators.required,
        Validators.min(0),
        // Validators.
      ]],
    })
  }
  get skill() {
    return this.skillForm.get('skill');
  }
  get selfRating() {
    return this.skillForm.get('selfRating');
  }
  get yearsExperience() {
    return this.skillForm.get('yearsExperience');
  }
  addSkill(formDetail:any) {
    this.errorMessage = null;
    let mentorSkill:Mentor_Skill = {mentor: this.skillService.mentor,selfRating:formDetail["selfRating"],
    yearsOfExperience:formDetail["yearsExperience"],skill:this.skillList.find(skill=>skill.name == formDetail["skill"])};
    console.log(mentorSkill.skill);
    
    this.skillService.addMentorSkill(mentorSkill).subscribe(
      (data)=>{
        window.alert("Your details are submitted successfully");
        this.buildSkillForm();
        this.submittedSkill = true;
      },
      (error)=>{
        console.log(error);
        if (error.error.message == "This skill exists for this mentor") {
          this.errorMessage = "This skill exists for this mentor";
        }
      }
    );
  }
  addMentorDetails(formDetails:any){
    this.errorMessage = null;
    this.skillService.mentor.linkedinURL = formDetails["linkedInURL"];
    this.skillService.mentor.timeslot = formDetails["timeslot"];
    this.skillService.mentor.yearsOfExperience = formDetails["yearsOfExperience"];
    this.skillService.addMentor(this.skillService.mentor).subscribe(
      (data)=>{
        window.alert("Your details are submitted successfully");
        this.mentorAdded = true;
      },
      (error)=>{
        console.log(error);
        if (error.error.message == "This LinkedIn URL is already being used") {
          this.errorMessage = "This LinkedIn URL is already being used";
        }
      }
    )
  }
}
