import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { Mentor_Skill } from './Mentor_Skill';
import { Mentor } from './Mentor';

@Injectable({
  providedIn: 'root'
})
export class SkillService {

  zuulURL:string = environment.zuulURL;
  signupURL:string = this.zuulURL+"user-signup-microservice/";
  mentor:Mentor = null;

  constructor(private http:HttpClient) { }

  getAllSkillsObservable(): Observable<any> {
    return this.http.get(this.signupURL+"skills");
  }
  addMentor(mentor:Mentor):Observable<any> {
    return this.http.post(this.signupURL+"addMentor",mentor);
  }
  addMentorSkill(mentorSkill:Mentor_Skill):Observable<any> {
    return this.http.post(this.signupURL+"addMentorSkill",mentorSkill);
  }
}
