import { Injectable } from '@angular/core';
import { SkillService } from './skill.service';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SkillGuardService  implements CanActivate  {
  
  constructor(private router:Router, private skillService:SkillService) { }

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    if(this.skillService.mentor!=null){
      return true;
    }
    this.router.navigate(["/register"]);
    return false;
  }
}

