package com.cognizant.usersignupmicroservice.exception;

public class LinkedInURLAlreadyExistsException extends Exception {

	public LinkedInURLAlreadyExistsException(String message){
		super(message);
	}
}
