import { USER } from './USER';

export interface Mentor {
    id:number,
    linkedinURL:string,
    yearsOfExperience:number,
    timeslot:string,
    user:USER
}