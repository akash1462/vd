import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm:FormGroup;
  errorMessage = null;
  
  constructor(private formBuild:FormBuilder, private userService:UserService, private router:Router) { }

  ngOnInit() {
    this.userService.setToken(null);
    this.userService.setRole(null);
    this.loginForm = this.formBuild.group({
      userId: ['',[
        Validators.required,
        Validators.maxLength(45),
        Validators.minLength(10),
        Validators.email
      ]],
      password: ['',[
        Validators.required,
        Validators.maxLength(15),
        Validators.minLength(3)
      ]]
    })
  }
  get userId(){
    return this.loginForm.get('userId');
  }
  get password(){
    return this.loginForm.get('password');
  }
  login(credentials:any) {
    this.userService.setToken(null);
    this.userService.setRole(null);
    this.userService.login(credentials["userId"],credentials["password"]).subscribe(
      (data)=>{
        this.userService.setToken(data.token);
        this.userService.setRole(data.role);
        this.userService.setDisplayName(data.name);
        this.errorMessage = null;
        if(this.userService.getRole() == "ROLE_M"){
          // this.router.navigate(["/admin"]);
        }
        else{
          // this.router.navigate(["/search"]);
        }
        console.log("Logged in");
        console.log(this.userService.getToken());
        console.log(this.userService.getRole());
        console.log(this.userService.getDisplayName());
        
               
      },
      (error)=>{
        console.log(error);
        this.errorMessage = "Credentials Invalid";        
      }
    )
  }
}
