package com.cognizant.usersignupmicroservice.exception;

public class MentorSkillAlreadyExistsException extends Exception {

	public MentorSkillAlreadyExistsException(String message) {
		super(message);
	}
}
